<!--  -->
<template>
  <div >
      这里是页面BBBBBBBBBBBBBBBB
<router-link :to="{name:'Home'}">跳转到B页面</router-link>
  </div>
</template>

<script>
export default {
  data () {
    return {
    };
  },

  components: {},

  computed: {},

  methods: {}
}

</script>
<style  scoped>
</style>