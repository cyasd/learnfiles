<!--  -->
<template>
  <div style="width:100%;height:500px;border:1;solid:1px">
      页面AAAAAAAAAAAAAA
  </div>
</template>

<script>
export default {
  data () {
    return {
    };
  },

  components: {},

  computed: {},

  methods: {}
}

</script>
<style  scoped>
</style>