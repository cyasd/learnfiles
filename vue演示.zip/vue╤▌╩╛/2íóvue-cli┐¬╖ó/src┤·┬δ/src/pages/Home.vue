<!--  -->
<template>
  <div >
      这里是home页面
      <br>
<router-link :to="{name:'A'}">跳转到A页面</router-link>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<router-link :to="{name:'B'}">跳转到B页面</router-link>
<router-view></router-view>
  </div>
</template>

<script>
export default {
  data () {
    return {
    };
  },

  components: {},

  computed: {},

  methods: {}
}

</script>
<style   scoped>
</style>