<!--  -->
<template>
  <div >
      home22222222222222页面
      <br>

<router-view></router-view>
  </div>
</template>

<script>
export default {
  data () {
    return {
    };
  },

  components: {},

  computed: {},

  methods: {}
}

</script>
<style   scoped>
</style>