<!--  -->
<template>
  <div >
      <a v-bind:href="url">
          <slot>如果不穿入数据的话就展示这里</slot>
          <slot name="firstSlot">如果不穿入数据的话就展示这里</slot>
           <slot name="secondSlot">如果不穿入数据的话就展示这里</slot>
      </a>
  </div>
</template>

<script>
export default {
  data () {
    return {
        
    };
  },
  props:{
      url:{
          type:String
      }
  },
 
  components: {},

  computed: {},

  methods: {}
}

</script>
<style  scoped>
</style>