<!--  -->
<template>
  <div style="border:1px solid;width:300px;height:300px">
      这里是一个子组件
      来自父组件的数据：<p v-text="textFromParent"></p>
      发射按钮：<Button @click="sendToParent">发射~</Button>
      <slot name="test1"></slot>
      <slot name="test2"></slot>
  </div>
</template>

<script>
export default {
  data () {
    return {
    };
  },
  props:{
      textFromParent:{
          type:String,
          required:true,
          validator:function(textFromParent){
              console.log(textFromParent);
              return true;
          }
      }
  },
  components: {},

  computed: {},

  methods: {
      sendToParent:function(){
          this.$emit('alertSonInfo',this.textFromParent);//发射
      },
      methodForParent:function(){
        alert("这里是子组件的方法~~~");
      }
  }
}

</script>
<style scoped>
</style>