import Vue from 'vue'
import Router from 'vue-router'
import A from '@/pages/A'
import B from '@/pages/B'
import Home from '@/pages/Home'
import Home2 from '@/pages/Home2'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/home',
      name: 'Home',
      component: Home,
      children:[
        {
          path: '/a',
          name: 'A',
          component: A,
        },{
          path: '/b',
          name: 'B',
          component: B,
        }
      ]
    },{
      path: '/home2',
      name: 'Home2',
      component: Home2,
    }
  ]
})
