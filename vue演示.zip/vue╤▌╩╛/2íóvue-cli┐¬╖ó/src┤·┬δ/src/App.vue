<template>
  <div id="app" >
    <!-- 这里是第一个页面
     <br>
     <router-link :to="{name:'Home'}">跳转到Home页面</router-link>
    <router-view></router-view> -->

    <son-component @alertSonInfo="alertInfoFromSon" text-from-parent="我是App.vue,你是我的子组件"></son-component>
  </div>
</template>

<script>
import SonComponent from './pages/SonComponent'


export default {
  name: 'App',
  data(){
    return {}
  },
  components:{
    'son-component':SonComponent
  },
  methods:{
    alertInfoFromSon:function(message){
      alert(message);
    }
  },
  created(){},
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #89b5e0;
  margin-top: 60px;
}

</style>
