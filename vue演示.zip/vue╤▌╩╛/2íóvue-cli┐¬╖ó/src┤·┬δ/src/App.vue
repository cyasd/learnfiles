<template>
  <div id="app" >
    这里是第一个页面
     <br>
     <router-link :to="{name:'Home',params:{id:123}}">跳转到Home页面</router-link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     <router-link :to="{path:'/home2',query:{id:123}}">跳转到Home2页面</router-link>
    <router-view></router-view> 




    <div style="width:100px;height:100px"></div>
    <son-component ref="SonComponent" @alertSonInfo="alertInfoFromSon" :text-from-parent="message"></son-component>

    <my-navigation :url="'http://www.baidu.com'">
       <p>这里通往百度~</p>
      <p slot="secondSlot">hahaha</p>
    </my-navigation>
  </div>
</template>

<script>
import SonComponent from './pages/SonComponent'
import MyNavigation from './pages/MyNavigation'

export default { 
  name: 'App',
  data(){
    return {
      message:"我是App.vue,你是我的子组件"
    }
  },
  components:{
    'son-component':SonComponent,
    'my-navigation':MyNavigation
  },
  methods:{
    alertInfoFromSon:function(message){
      alert(message);
    },
  },
  mounted(){
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #89b5e0;
  margin-top: 60px;
}

</style>
